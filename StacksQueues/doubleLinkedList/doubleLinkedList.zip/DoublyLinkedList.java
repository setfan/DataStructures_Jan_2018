//package doubleLinkedList;

import java.security.InvalidParameterException;
import java.util.Iterator;
import java.util.function.Consumer;

public class DoublyLinkedList<E> implements Iterable<E> {

    private Node haed;
    private Node tail;
    private int size;

    public DoublyLinkedList() {
        this.haed = null;
        this.tail = null;
        this.setSize(0);
    }

    public int size() {
        return this.size;
    }

    private void setSize(int size) {
        this.size = size;
    }


    @SuppressWarnings("unchecked")
    public void addFirst(E element) {
        if (this.size == 0){
            this.haed = this.tail = new Node(element);
        } else {
            Node newHead = new Node(element);
            newHead.next = this.haed;
            this.haed.setPrevious(newHead);
            this.haed = newHead;
        }
        this.size++;

    }

    public void addLast(E element) {
        if (this.size == 0){
            this.haed = this.tail = new Node(element);
        } else {
            Node newTail = new Node(element);
            newTail.previous = this.tail;
            this.tail.next = newTail;
            this.tail = newTail;
        }
        this.size++;
    }

    public E removeFirst() {
        if (this.size == 0){
            throw new InvalidParameterException("List is empty.");
        }
        E elemToRemove = (E) this.haed.value;
        this.haed = this.haed.next;
        if (this.haed != null){
            this.haed.previous = null;
        } else {
            this.tail = null;
        }
        this.size--;
        return elemToRemove;
    }

    public E removeLast() {
        if (this.size == 0){
            throw new InvalidParameterException("List is empty.");
        }
        E elemToRemove = (E) this.tail.value;
        this.tail = this.tail.getPrevious();
        if (this.tail != null){
            this.tail.next = null;
        } else {
            this.haed = null;
        }
        this.size--;
        return elemToRemove;
    }

    public E[] toArray() {
        E[] resultArray = (E[]) new Object[this.size];
        int index = 0;
        Node current = this.haed;
        while (current != null){
            resultArray[index] = (E) current.value;
            current = current.getNext();
            index++;
        }

        return resultArray;
    }

    public class Node<E>{
        private E value;
        private Node next;
        private Node previous;

        public Node(E value) {
            this.setValue(value);
            this.setNext(null);
            this.setPrevious(null);
        }

        public E getValue() {
            return this.value;
        }

        void setValue(E value) {
            this.value = value;
        }

        public Node getNext() {
            return this.next;
        }

        void setNext(Node next) {
            this.next = next;
        }

        public Node getPrevious() {
            return this.previous;
        }

        void setPrevious(Node previous) {
            this.previous = previous;
        }
    }

    @Override
    public Iterator<E> iterator() {
        return new Iterator<E>() {
            Node<E> currentNode = haed;
            @Override
            public boolean hasNext() {
                return this.currentNode != null;
            }
            @Override
            public E next() {
                E element = this.currentNode.getValue();
                this.currentNode = this.currentNode.getNext();
                return element;
            }
        };
    }

    @Override
    public String toString() {
        StringBuilder result = new StringBuilder();

        for (E t : this) {
            result.append(t).append(" ");
        }

        return result.toString().trim();
    }

    @Override
    public void forEach(Consumer<? super E> action) {
        Node current = this.haed;

        while (current != null){
            E e = (E) current.getValue();
            action.accept(e);

            current = current.next;
        }
    }

}
